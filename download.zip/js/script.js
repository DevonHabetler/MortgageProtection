function formatCurrency(input) {
    // Remove non-numeric characters
    let value = input.value.replace(/[^0-9]/g, '');

    // Format as currency with $ and commas
    if (value.length > 0) {
        value = `$${parseInt(value, 10).toLocaleString()}`;
    }

    // Update the input value
    input.value = value;
}

function calculate() {
    // Get input values and remove $ and commas
    const mortgageBalance = parseFloat(document.getElementById('mortgageBalance').value.replace(/[^0-9.]/g, ''));
    const monthlyPayment = parseFloat(document.getElementById('monthlyPayment').value.replace(/[^0-9.]/g, ''));
    const age = parseFloat(document.getElementById('age').value);

    // Validate inputs
    if (isNaN(mortgageBalance) || isNaN(monthlyPayment) || isNaN(age)) {
        alert("Please enter valid numbers for all fields.");
        return;
    }

    // Formula for E2
    const e2 = () => {
        if (age >= 60 && age <= 64 && mortgageBalance >= 650000) return "DNQ";
        if (age >= 65 && age <= 69 && mortgageBalance >= 450000) return "DNQ";
        if (age >= 70 && age <= 74 && mortgageBalance >= 250000) return "DNQ";
        if (age > 75 && mortgageBalance > 0) return "DNQ";
        return "";
    };

    // Formula for F2
    const f2 = () => {
        if (age > 45 || age < 18) return "DNQ";
        return "";
    };

    // Formula for F3
    const f3 = () => {
        if (age > 0 && age <= 54) return "DNQ";
        return "";
    };

    // Format results as dollars
    const formatDollars = (value) => {
        if (value === "DNQ") return "DNQ";
        return `$${value.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`;
    };

    // Section 1: Mortgage Protection
    const d8 = () => {
        if (mortgageBalance === "" || e2() === "DNQ" || age < 18 || age >= 70) return "DNQ";
        if (age >= 18 && age <= 24) return mortgageBalance / 5500 + 10;
        if (age >= 25 && age <= 29) return mortgageBalance / 5000 + 10;
        if (age >= 30 && age <= 34) return mortgageBalance / 4500 + 10;
        if (age >= 35 && age <= 39) return mortgageBalance / 3500 + 10;
        if (age >= 40 && age <= 44) return mortgageBalance / 2500 + 10;
        if (age >= 45 && age <= 49) return mortgageBalance / 1700 + 10;
        if (age >= 50 && age <= 54) return mortgageBalance / 1100 + 10;
        if (age >= 55 && age <= 59) return mortgageBalance / 750 + 10;
        if (age >= 60 && age <= 64) return mortgageBalance / 525 + 10;
        if (age >= 65 && age <= 70) return mortgageBalance / 450 + 10;
        return "";
    };

    const c8 = () => {
        const avgHealth = d8();
        if (avgHealth === "DNQ") return "DNQ";
        return avgHealth - avgHealth * 0.2;
    };

    const e8 = () => {
        const avgHealth = d8();
        if (avgHealth === "DNQ") return "DNQ";
        return avgHealth + avgHealth * 0.2;
    };

    document.getElementById('greatHealth1').textContent = formatDollars(c8());
    document.getElementById('averageHealth1').textContent = formatDollars(d8());
    document.getElementById('badHealth1').textContent = formatDollars(e8());

    // Section 2: Mortgage Protection/CBO
    const d13 = () => {
        if (mortgageBalance === "" || f2() === "DNQ" || age < 18 || age > 50) return "DNQ";
        if (age >= 18 && age <= 24) return mortgageBalance / 2302 + 10;
        if (age >= 25 && age <= 29) return mortgageBalance / 2172 + 10;
        if (age >= 30 && age <= 34) return mortgageBalance / 1992 + 10;
        if (age >= 35 && age <= 39) return mortgageBalance / 1706 + 10;
        if (age >= 40 && age <= 44) return mortgageBalance / 1291 + 10;
        if (age >= 45 && age <= 49) return mortgageBalance / 925 + 10;
        return "";
    };

    const c13 = () => {
        const avgHealth = d13();
        if (avgHealth === "DNQ") return "DNQ";
        return avgHealth - avgHealth * 0.2;
    };

    const e13 = () => {
        const avgHealth = d13();
        if (avgHealth === "DNQ") return "DNQ";
        return avgHealth + avgHealth * 0.2;
    };

    document.getElementById('greatHealth2').textContent = formatDollars(c13());
    document.getElementById('averageHealth2').textContent = formatDollars(d13());
    document.getElementById('badHealth2').textContent = formatDollars(e13());

    // Section 3: Payment Protection
    const calculatePaymentProtection = (years) => {
        if (monthlyPayment === "" || f3() === "DNQ" || age < 55) return "DNQ";
        if (age >= 55 && age <= 59) return (monthlyPayment * 12 * years) / 265 + 10;
        if (age >= 60 && age <= 64) return (monthlyPayment * 12 * years) / 236 + 10;
        if (age >= 65 && age <= 69) return (monthlyPayment * 12 * years) / 183 + 10;
        if (age >= 70 && age <= 74) return (monthlyPayment * 12 * years) / 127 + 10;
        if (age >= 75 && age <= 79) return (monthlyPayment * 12 * years) / 88 + 10;
        if (age >= 80 && age <= 84) return (monthlyPayment * 12 * years) / 68 + 10;
        if (age > 85) return "DNQ";
        return "";
    };

    const calculateGreatHealth = (value) => {
        if (value === "DNQ") return "DNQ";
        return value - value * 0.2;
    };

    const calculateBadHealth = (value) => {
        if (value === "DNQ") return "DNQ";
        return value + value * 0.2;
    };

    const paymentProtection1Year = calculatePaymentProtection(1);
    const paymentProtection2Years = calculatePaymentProtection(2);
    const paymentProtection3Years = calculatePaymentProtection(3);

    document.getElementById('greatHealth3_1').textContent = formatDollars(calculateGreatHealth(paymentProtection1Year));
    document.getElementById('averageHealth3_1').textContent = formatDollars(paymentProtection1Year);
    document.getElementById('badHealth3_1').textContent = formatDollars(calculateBadHealth(paymentProtection1Year));

    document.getElementById('greatHealth3_2').textContent = formatDollars(calculateGreatHealth(paymentProtection2Years));
    document.getElementById('averageHealth3_2').textContent = formatDollars(paymentProtection2Years);
    document.getElementById('badHealth3_2').textContent = formatDollars(calculateBadHealth(paymentProtection2Years));

    document.getElementById('greatHealth3_3').textContent = formatDollars(calculateGreatHealth(paymentProtection3Years));
    document.getElementById('averageHealth3_3').textContent = formatDollars(paymentProtection3Years);
    document.getElementById('badHealth3_3').textContent = formatDollars(calculateBadHealth(paymentProtection3Years));
}